package com.example.myapplication_9;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.osgeo.proj4j.CRSFactory;
import org.osgeo.proj4j.CoordinateReferenceSystem;
import org.osgeo.proj4j.Proj4jException;
import org.osgeo.proj4j.ProjCoordinate;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.compass.CompassOverlay;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class work_activity extends AppCompatActivity {

    MapView map;
    MapController mapController;
    Button btn_update;
    TextView lat, lon, utmX, utmY, speedTextView;
    double ID = 1;
    LocationManager locationManager;
    LocationListener locationListener;
    private Location previousLocation;
    private long previousTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_work);

        map = findViewById(R.id.mapView);
        btn_update = findViewById(R.id.btn_update_location);
        lat = findViewById(R.id.textView_lat);
        lon = findViewById(R.id.textView_lon);
        utmX = findViewById(R.id.textView_utm_x);
        utmY = findViewById(R.id.textView_utm_y);
        speedTextView = findViewById(R.id.speedTextView);

        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setBuiltInZoomControls(true);
        map.setMultiTouchControls(true);
        mapController = (MapController) map.getController();

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
                    if (ActivityCompat.checkSelfPermission(work_activity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                            && ActivityCompat.checkSelfPermission(work_activity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                        ActivityCompat.requestPermissions(work_activity.this, new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
                        }, 100);

                        return;
                    } else {
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                        Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (lastKnownLocation != null) {
                            updateLocation(lastKnownLocation);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                updateLocation(location);
            }
            // Implement other methods of LocationListener if needed
        };
        locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
    }

    private final CRSFactory crsFactory = new CRSFactory();

    private void updateLocation(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        lat.setText(String.valueOf(latitude));
        lat.setBackgroundColor(Color.YELLOW);
        lon.setText(String.valueOf(longitude));
        lon.setBackgroundColor(Color.YELLOW);

        // Calculate speed
        float speed = 0.0f;
        if (previousLocation != null) {
            long currentTime = System.currentTimeMillis();
            long timeDifference = currentTime - previousTime;
            float distance = location.distanceTo(previousLocation);
            speed = (distance / timeDifference) * 1000; // Convert to meters per second

            // Display speed
            speedTextView.setText(String.format(Locale.getDefault(), "%.2f m/s", speed));
            speedTextView.setBackgroundColor(Color.YELLOW); // Set the background color to yellow
        }
        // Update previous location and time
        previousLocation = location;
        previousTime = System.currentTimeMillis();

        // Convert latitude and longitude to UTM
        try {
            // Define WGS84 coordinate system
            CoordinateReferenceSystem wgs84 = crsFactory.createFromName("EPSG:4326"); // WGS84

            // Define UTM coordinate system
            CoordinateReferenceSystem utm = crsFactory.createFromName("EPSG:32639"); // UTM zone 1N (adjust for your region)

            // Create a ProjCoordinate instance for the user's location
            ProjCoordinate userLocation = new ProjCoordinate(longitude, latitude);

            // Transform the user's location from WGS84 to UTM
            ProjCoordinate utmCoords = new ProjCoordinate();
            utmCoords = wgs84.getProjection().inverseProject(userLocation, utmCoords);
            utmCoords = utm.getProjection().project(utmCoords, utmCoords);

            // Display UTM coordinates
            utmX.setText(String.valueOf(utmCoords.x));
            utmX.setBackgroundColor(Color.YELLOW); // Set the background color to yellow
            utmY.setText(String.valueOf(utmCoords.y));
            utmY.setBackgroundColor(Color.YELLOW); // Set the background color to yellow
        } catch (Proj4jException e) {
            e.printStackTrace();
        }

        // Clear existing overlays (markers) on the map
        map.getOverlays().clear();
        // Create a new marker at the user's current location
        Marker marker = new Marker(map);
        marker.setPosition(new GeoPoint(location.getLatitude(), location.getLongitude()));
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        map.getOverlays().add(marker);

        // Zoom to the user's location
        mapController.animateTo(new GeoPoint(latitude, longitude)); // Smoothly pan to user's location
        mapController.setZoom(18); // Adjust the zoom level as needed for better visibility
        map.invalidate(); // Refresh the map to display the changes

        // Compass overlay
        CompassOverlay compassOverlay = new CompassOverlay(this, map);
        compassOverlay.enableCompass();
        map.getOverlays().add(compassOverlay);

        // Send location to server
        sendLocationToServer(latitude, longitude, speed);
    }

    private int getBatteryPercentage() {
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = getApplicationContext().registerReceiver(null, ifilter);

        int level = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        int scale = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;

        float batteryPct = level / (float) scale;
        return (int) (batteryPct * 100);
    }

    private void sendLocationToServer(double latitude, double longitude, float speed) {
        new Thread(() -> {
            try {
                URL url = new URL("http://192.168.43.234:8090/send_location");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setDoOutput(true);
                //send battery percentage
                int batteryPercentage = getBatteryPercentage();
                String jsonInputString = String.format(Locale.getDefault(),
                        "{\"id\": %d, \"latitude\": %f, \"longitude\": %f, \"speed\": %.2f, \"battery\": %d}",
                        ID, latitude, longitude, speed, batteryPercentage);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                if (code == HttpURLConnection.HTTP_OK) {
                    // Handle success
                } else {
                    // Handle failure
                }
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
